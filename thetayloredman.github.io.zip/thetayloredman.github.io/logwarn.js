// Sends warnings to console log.
console.log(
    '%cSTOP!',
    'color:red;font-family:system-ui;font-size:4rem;-webkit-text-stroke: 1px black;font-weight:bold'
)

console.log(
    '%cThis is a browser feature intended for developers. If someone told you to copy and paste something here, there\'s a chance someone is targeting you for what is called a Self-XSS attack!',
    'color:white;font-family:system-ui;font-size:1rem;font-weight:bold'
)

console.log(
    '%cI\'m not kidding with you here. This is real. Unless you know what you are doing, DO NOT PASTE ANYTHING IN HERE!',
    'color:white;font-family:system-ui;font-size:1rem;font-weight:bold'
)

console.log(
    '%cIt could contain malware, Self-XSS payloads, or a LOT more.',
    'color:white;font-family:system-ui;font-size:1rem;font-weight:bold'
)

console.log(
    '%cPlease,',
    'color:white;font-family:system-ui;font-size:1rem;font-weight:bold'
)

console.log(
    '%cDO NOT RUN ANY SCRIPTS YOU DO NOT UNDERSTAND HERE!',
    'color:red;font-family:system-ui;font-size:2rem;-webkit-text-stroke: 1px black;font-weight:bold'
)

console.warn('InternalDepreciationWarning: /logwarn.js is depreciated and will be removed soon. Please stop using it.')